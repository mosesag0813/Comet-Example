var mouse = document.createElement('onclick');
var button = document.innerHTML.getAttribute('@active');
mouse.button().click();
