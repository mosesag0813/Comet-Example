function onclick(){
  import comet.min.js from 'CometJS'
  var use = require('use');
  use(comet.min.js)
}
onclick();
